EDGE JOURNAL - UPDATED CALENDAR

Open index.html in a modern browser (Chrome or Edge).

Calendar change:
- Clicking/tapping any calendar date opens the Add Trade form immediately.
- The selected date is automatically filled into the Entry date field.
- The existing + Add trade buttons remain available on the Calendar, Dashboard, and Trade Journal pages.

This build remains a local browser demo. It does not yet include cloud login or cross-device synchronization. Browser-local records and attachments do not automatically move between Windows and iPad. Export backups regularly.
